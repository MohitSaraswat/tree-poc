import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  selectedItem: any[] = [];
  selectedRightItem: any[] = [];
  selectedRightItemRef: any[] = [];
  list: any[] = [];
  rightList: any[] = [];

  constructor() {
    this.list = [
      {name: 'a', rel_path: 'a'},
      {name: 'b', rel_path: 'a/b'},
      {name: 'c', rel_path: 'a/b/c'}
    ];
  }
  
  
  setRow(data, index) {
    
    if (!this.selectedItem.includes(data)) {
      //this.selectedIndexes.push(index);
      this.selectedItem.push(data);
      console.log(this.selectedItem);
      
    } else {
      let indexDel = this.selectedItem.indexOf(data);
      //let duplicateEl = this.selectedItem.indexOf(indexDel);
      this.selectedItem.splice(indexDel, 1);
      console.log(this.selectedItem);
      
    }
  }

  setRightRow(data, index) {
    
    if (!this.selectedRightItem.includes(data)) {
      //this.selectedIndexes.push(index);
      this.selectedRightItem.push(data);
      console.log(this.selectedRightItem);
      
    } else {
      let indexDel = this.selectedRightItem.indexOf(data);
      //let duplicateEl = this.selectedItem.indexOf(indexDel);
      this.selectedRightItem.splice(indexDel, 1);
      console.log(this.selectedRightItem);
      
    }
  }

  leftToRight() {
    this.selectedItem.forEach(e => {
      this.rightList.push(e);
      let index = this.list.indexOf(e);
      this.list.splice(index, 1);
      console.log(this.selectedItem);
    });
    this.selectedItem = [];
    //this.rightList = this.selectedItem.slice();
    // this.selectedRightItem = this.selectedRightItemRef;
    //console.log(this.selectedRightItem);
  }

  rightToLeft() {
    this.selectedRightItem.forEach(e => {
      this.list.push(e);
      let index = this.rightList.indexOf(e);
      this.rightList.splice(index, 1);
      console.log(this.selectedRightItem);
    });
    this.selectedRightItem = [];
  }

}
